<?php
?>
<div>XtreamUI R8 - Theme By YZ</div>
    <script src="assets/js/vendor.min.js" type="text/javascript"></script>
    <script src="assets/yz/js/pcoded.min.js"></script>
	<script src="assets/yz/js/vertical-layout.js"></script>	



<style>


.footer {
    display: none;
}
.container-fluid {
    max-width: 100% !important;
}
body {
    padding-bottom: 0px !important;
}

</style>

</div>
</div>
</div>
</div>
</div>